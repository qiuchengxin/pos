create procedure update_daily_pkdaily_onl()
  BEGIN
	#Routine body goes here...
			UPDATE pay_data.users SET pay_data.users.daily = '0',pay_data.users.pkdaily = '0';
END;

