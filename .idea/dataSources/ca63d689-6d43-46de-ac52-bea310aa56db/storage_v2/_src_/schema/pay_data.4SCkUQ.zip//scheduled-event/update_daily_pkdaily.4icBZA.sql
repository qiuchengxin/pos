create definer = root@`%` event update_daily_pkdaily
  on schedule
    every '1' DAY
      starts '2018-11-01 00:00:00'
  enable
do
  CALL update_daily_pkdaily_onl;

